import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Router } from '@angular/router';
import { catchError, map } from 'rxjs/operators';
import { of, throwError } from 'rxjs';
import { TokenModel } from '@shared/models/token-models';
import { LoginModel } from '@shared/models/authentication-models';
import { Constants } from '../models/Constants';

@Injectable()
export class AuthenticationService {
  constructor(private router: Router, private httpClient: HttpClient) {}

  login(loginModel: LoginModel) {
    return this.httpClient
      .post(environment.apiEndPoint.auth.login, loginModel)
      .pipe(
        map((res) => res),
        map((body) => body),
        catchError((err) => throwError(err))
      );
  }

  getInstaToken() {
    let instaTokenDetails = localStorage.getItem(Constants.instaToken);
    return JSON.parse(instaTokenDetails || '').access_token;
  }

  logOut() {
    localStorage.removeItem(environment.tokenName);
    this.router.navigate(['/login']);
  }

  get tokenDetails(): TokenModel | null {
    let td = localStorage.getItem(environment.tokenName);
    if (td) {
      let tokenDetails: TokenModel = JSON.parse(td);
      let dt = new Date().getTime();
      if (tokenDetails && tokenDetails.expires > dt) {
        return tokenDetails;
      }
    }
    return null;
  }

  get isLoggedIn() {
    let tokenDetails: TokenModel | null = this.tokenDetails;
    if (tokenDetails) return true;
    return false;
  }
}
