export enum DataSourceType {
    Array = "Array",
    Object = "Object",
    ObjectArray = "ObjectArray",
}

