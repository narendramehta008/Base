export class CardTemplate {
    imageSrc: string;
    title: string = 'title';
    text: string = 'Some quick example text to build on the card title and make up the bulk of the card\'s content.';
    redirectUrl: string;
    showDownload = true;
}

