export interface FormatNumber {
    locale: string,
    digitsInfo?: string
}
