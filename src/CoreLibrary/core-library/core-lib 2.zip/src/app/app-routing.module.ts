import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from './core/services/auth-guard.service';
import { AuthenticationService } from './core/services/authentication.service';
import { AdministrationComponent } from './pages/administration/administration.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LoginComponent } from './pages/login/login.component';
import { OauthComponent } from './pages/oauth/oauth.component';
import { SampleChartsComponent } from './pages/sample-charts/sample-charts.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    canActivate: [AuthGuardService],
    data: { depth: 1 },
  },
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [AuthGuardService],
    data: { depth: 1 },
  },
  { path: 'oauth', component: OauthComponent, data: { depth: 1 } },
  {
    path: 'administration',
    component: AdministrationComponent,
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuardService],
    data: { depth: 1 },
  },
  {
    path: 'dev',
    loadChildren: () =>
      import('./pages/dev/dev-routing.module').then((m) => m.DevRoutingModule),
    canActivate: [AuthGuardService],
    data: { depth: 1 },
  },
  {
    path: 'sample-charts',
    component: SampleChartsComponent,
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: 'animations',
    loadChildren: () =>
      import('./pages/animations/animations-routing.module').then(
        (m) => m.AnimationsRoutingModule
      ),
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: 'services',
    loadChildren: () =>
      import('./pages/services/services-routing.module').then(
        (m) => m.ServicesRoutingModule
      ),
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: 'dsa',
    loadChildren: () =>
      import('./pages/dsa/dsa-routing.module').then((m) => m.DsRoutingModule),
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: 'designs',
    loadChildren: () =>
      import('./pages/designs/designs-routing.module').then(
        (m) => m.DesignsRoutingModule
      ),
    canActivate: [AuthGuardService],
    data: { depth: 2 },
  },
  {
    path: '**',
    redirectTo: 'dashboard',
    data: { depth: 1 },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  providers: [AuthGuardService, AuthenticationService],
  exports: [RouterModule],
})
export class AppRoutingModule {}
