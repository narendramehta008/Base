import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ServicesComponent } from './services.component';
import { InstaComponent } from './insta/insta.component';
import { TwtComponent } from './twt/twt.component';
import { PinComponent } from './pin/pin.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: ServicesComponent,
        data: { depth: 2 },
      },
      {
        path: 'insta',
        component: InstaComponent,
        data: { depth: 3 },
      },
      {
        path: 'twt',
        component: TwtComponent,
        data: { depth: 3 },
      },
      {
        path: 'pin',
        component: PinComponent,
        data: { depth: 3 },
      },
    ],
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ServicesRoutingModule {}
