import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { SampleData } from '@app/core/contents/SampleData';
import { QueryModel } from '@app/core/models/QueryModels';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';
import { environment } from '@environments/environment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  dataSource: CardComponent[] = [];
  instDataSource: CardComponent[] = [];
  // cursor: string;
  userInfo: any;
  // pageInfo: PageInfo;

  constructor(
    private utilService: UtilsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // this.utilService.SampleData.images.slice(0, 10).map((img) => {
    //   let card = new CardComponent(this.utilService).setCardValue({
    //     media: { src: img },
    //   });
    //   // card.onHoverShowDetails = true;
    //   this.dataSource.push(card);
    // });

    let images = [...this.utilService.SampleData.images.slice(0, 10)];
    for (let index = 0; index < images.slice(0, 10).length - 1; index++) {
      let card = new CardComponent(this.utilService).setCards([
        {
          media: {
            src: images[index],
          },
        },
        {
          media: {
            src: images[index + 1],
          },
        },
      ]);
      // card.onHoverShowDetails = true;
      this.dataSource.push(card);
    }
    this.cdr.detectChanges();
  }
  ngAfterViewInit() {}

  loadImages() {
    // let postData:InstaPagination ={}
  }
}
interface PageInfo {
  user_id: string;
  currenPage: number;
}

interface InstaPagination {
  id: string;
  first: number;
  after: string;
}
