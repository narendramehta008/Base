import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-ang',
  templateUrl: './ang.component.html',
  styleUrls: ['./ang.component.scss'],
})
export class AngComponent implements OnInit {
  cards: CardComponent[];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    this.cards = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Basics of Angular',
        text: 'Software framework for building web, desktop, mobile and other applications.',
        redirectUrl: '/dev/ang/basics',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/info-blue.png',
          ext: 'png',
        },
      }),
    ];
  }
}
