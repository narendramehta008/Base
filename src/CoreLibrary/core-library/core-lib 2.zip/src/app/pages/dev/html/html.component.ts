import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-html',
  templateUrl: './html.component.html',
  styleUrls: ['./html.component.scss'],
})
export class HtmlComponent implements OnInit {
  cards: CardComponent[];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    this.cards = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Basics of Html',
        text: 'Mark up language.',
        redirectUrl: '/dev/html/basics',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/info-blue.png',
          ext: 'png',
        },
      }),
    ];
  }
}
