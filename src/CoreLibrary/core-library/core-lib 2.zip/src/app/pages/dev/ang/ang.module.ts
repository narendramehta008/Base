import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AngRoutingModule } from './ang-routing.module';
import { AngComponent } from './ang.component';
import { BasicsComponent } from './basics/basics.component';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [AngComponent, BasicsComponent],
  imports: [CommonModule, AngRoutingModule, SharedModule],
})
export class AngModule {}
