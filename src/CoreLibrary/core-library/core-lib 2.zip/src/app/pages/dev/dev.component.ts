import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-dev',
  templateUrl: './dev.component.html',
  styleUrls: ['./dev.component.scss'],
})
export class DevComponent implements OnInit {
  cards: CardComponent[];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    this.cards = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Angular',
        text: 'Angular is an design framework and development platform ...',
        redirectUrl: '/dev/ang',
        redirectName: 'Visit',
        media: {
          src: 'https://angular.io/assets/images/logos/angular/angular.svg',
          ext: 'svg',
        },
      }),
      new CardComponent(this.utilService).setCardValue({
        title: 'Dot net',
        text: 'Software framework for building web, desktop, mobile and other applications.',
        redirectUrl: '/dev/dot-net',
        redirectName: 'Visit',
        media: {
          src: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/.NET_Core_Logo.svg/768px-.NET_Core_Logo.svg.png',
          ext: 'png',
        },
      }),
      new CardComponent(this.utilService).setCardValue({
        title: 'HTML',
        text: 'Mark up language.',
        redirectUrl: '/dev/html',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/html5.png',
          ext: 'png',
        },
      }),
      new CardComponent(this.utilService).setCardValue({
        title: 'CSS',
        text: 'Software framework for building web, desktop, mobile and other applications.',
        redirectUrl: '/dev/css',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/css3.png',
          ext: 'png',
        },
      }),
    ];
  }
}
