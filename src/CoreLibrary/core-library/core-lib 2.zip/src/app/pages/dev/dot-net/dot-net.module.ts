import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DotNetRoutingModule } from './dot-net-routing.module';
import { DotNetComponent } from './dot-net.component';
import { BasicsComponent } from './basics/basics.component';
import { SharedModule } from '@app/shared/shared.module';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
  declarations: [DotNetComponent, BasicsComponent],
  imports: [CommonModule, DotNetRoutingModule, SharedModule],
})
export class DotNetModule {}
