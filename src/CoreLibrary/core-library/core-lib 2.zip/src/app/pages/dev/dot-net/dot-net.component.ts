import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-dot-net',
  templateUrl: './dot-net.component.html',
  styleUrls: ['./dot-net.component.scss'],
})
export class DotNetComponent implements OnInit {
  cards: CardComponent[];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    this.cards = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Basics of .Net',
        text: 'Software framework for building web, desktop, mobile and other applications.',
        redirectUrl: '/dev/dot-net/basics',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/info-blue.png',
          ext: 'png',
        },
      }),
    ];
  }
}
