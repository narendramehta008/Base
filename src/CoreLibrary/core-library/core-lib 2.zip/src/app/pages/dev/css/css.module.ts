import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CssRoutingModule } from './css-routing.module';
import { CssComponent } from './css.component';
import { BasicsComponent } from './basics/basics.component';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [CssComponent, BasicsComponent],
  imports: [CommonModule, CssRoutingModule, SharedModule],
})
export class CssModule {}
