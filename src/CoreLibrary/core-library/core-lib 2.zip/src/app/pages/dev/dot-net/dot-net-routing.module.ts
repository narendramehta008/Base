import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BasicsComponent } from './basics/basics.component';
import { DotNetComponent } from './dot-net.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: DotNetComponent,
      },
      {
        path: 'basics',
        component: BasicsComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DotNetRoutingModule {}
