import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-css',
  templateUrl: './css.component.html',
  styleUrls: ['./css.component.scss'],
})
export class CssComponent implements OnInit {
  cards: CardComponent[];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    this.cards = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Basics of CSS',
        text: 'Style the data.',
        redirectUrl: '/dev/css/basics',
        redirectName: 'Visit',
        media: {
          src: '/assets/images/info-blue.png',
          ext: 'png',
        },
      }),
    ];
  }
}
