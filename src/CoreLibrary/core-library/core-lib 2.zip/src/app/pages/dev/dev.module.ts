import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DevRoutingModule } from './dev-routing.module';
import { DevComponent } from './dev.component';
import { SharedModule } from '@app/shared/shared.module';
import { DotNetModule } from './dot-net/dot-net.module';
import { AngRoutingModule } from './ang/ang-routing.module';
import { AngModule } from './ang/ang.module';
import { HtmlModule } from './html/html.module';
import { CssModule } from './css/css.module';

@NgModule({
  declarations: [DevComponent],
  imports: [
    CommonModule,
    DevRoutingModule,
    DotNetModule,
    AngRoutingModule,
    AngModule,
    HtmlModule,
    CssModule,
    SharedModule,
  ],
})
export class DevModule {}
