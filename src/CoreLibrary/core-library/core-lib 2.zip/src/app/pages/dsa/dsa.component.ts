import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dsa',
  templateUrl: './dsa.component.html',
  styleUrls: ['./dsa.component.scss']
})
export class DsaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
