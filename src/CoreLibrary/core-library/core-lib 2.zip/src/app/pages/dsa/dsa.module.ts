import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DsRoutingModule } from './dsa-routing.module';
import { IntroductionComponent } from './introduction/introduction.component';
import { DsaComponent } from './dsa.component';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [IntroductionComponent, DsaComponent],
  imports: [CommonModule, DsRoutingModule, SharedModule],
})
export class DsModule {}
