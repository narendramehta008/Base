import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DesignsRoutingModule } from './designs-routing.module';
import { DesignsComponent } from './designs.component';
import { FormsModule } from '@angular/forms';
import { CoreModule } from '@app/core/core.module';
import { FormModule } from '@app/shared/modules/form/form.module';
import { SharedModule } from '@app/shared/shared.module';
import { NeuModule } from './neu/neu.module';
import { GlassModule } from './glass/glass.module';

@NgModule({
  declarations: [DesignsComponent],
  imports: [
    CommonModule,
    DesignsRoutingModule,

    CoreModule,
    SharedModule,
    FormsModule,
    FormModule,
    NeuModule,
    GlassModule,
  ],
})
export class DesignsModule {}
