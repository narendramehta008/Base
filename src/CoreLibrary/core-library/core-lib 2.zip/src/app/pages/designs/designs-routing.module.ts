import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DesignsComponent } from './designs.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: DesignsComponent,
      },
      {
        path: 'glass',
        loadChildren: () =>
          import('./glass/glass-routing.module').then(
            (m) => m.GlassRoutingModule
          ),
      },
      {
        path: 'neu',
        loadChildren: () =>
          import('./neu/neu-routing.module').then((m) => m.NeuRoutingModule),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DesignsRoutingModule {}
