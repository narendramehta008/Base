import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NeuRoutingModule } from './neu-routing.module';
import { NeuComponent } from './neu.component';
import { BasicsComponent } from './basics/basics.component';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [NeuComponent, BasicsComponent],
  imports: [CommonModule, NeuRoutingModule, SharedModule],
})
export class NeuModule {}
