
export const environment = {
  serverUrl: 'https://corelibrary.herokuapp.com/api/',
  serverOrigin: 'https://corelibrary.herokuapp.com',

  // serverUrl: 'https://localhost:44373/api/',
  // serverOrigin: 'https://localhost:44373',

  tokenName: 'tokenDetails',
  apiEndPoint: {
    auth: {
      login: 'auth/login',
      register: 'auth/register',
    },
    account: {
      user: 'account/user'
    },
    file: {
      downloadFile: 'file/DownloadFile'
    },
    twt: {
      tweets: 'twt/Tweets'
    },
    insta: {
      httpRequest: 'insta/httpRequest'
    },

  },
  production: true
};
