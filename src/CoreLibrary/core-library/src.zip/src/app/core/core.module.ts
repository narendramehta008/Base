import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IsLastIndexPipe, Listing } from './pipes/is-last-index.pipe';

@NgModule({
  declarations: [IsLastIndexPipe, Listing],
  imports: [CommonModule],
  exports: [IsLastIndexPipe, Listing],
  providers: [],
})
export class CoreModule {}
