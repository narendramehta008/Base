import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'isLastIndex',
})
export class IsLastIndexPipe implements PipeTransform {
  transform<T>(
    value: ReadonlyArray<T> | null | undefined,
    index: number
  ): boolean {
    return index + 1 == new Listing().transform(value).length;
  }
}

@Pipe({
  name: 'listing',
})
export class Listing implements PipeTransform {
  transform<T>(value: ReadonlyArray<T> | null | undefined): ReadonlyArray<T> {
    return value ?? [];
  }
}
