import { HttpRequest } from "@angular/common/http";

// export class BtspRequest{
    
//     constructor() {
//     this.request = new 
//     }
//     request?: HttpRequest<any> | undefined;

// }