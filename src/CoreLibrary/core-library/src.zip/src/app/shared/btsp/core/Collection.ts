export interface Collection {
  info: Info;
  item: Item[];
  event: Event[];
  variable: Variable[];
}

export interface Info {
  _postman_id: string;
  name: string;
  schema: string;
  _exporter_id: string;
  _collection_link?: string;
}

export interface Item {
  id?: number;
  level?: number;
  paths?: Path[];
  name: string;

  item?: Item[];
  request?: Request;
  response?: Response[];
}

export interface Path {
  id: number;
  name: string;
}

export interface Request {
  auth?: Auth;
  method: string;
  header: Header[];
  url: Url;
  body?: Body;
}

export interface Auth {
  type: string;
  basic?: Basic[];
}

export interface Basic {
  key: string;
  value: string;
  type: string;
}

export interface Header {
  key: string;
  value: string;
  type: string;
  disabled?: boolean;
}

export interface Url {
  raw: string;
  protocol?: string;
  host: string[];
  path?: string[];
  query?: Query[];
}

export interface Query {
  key: string;
  value: string;
  disabled?: boolean;
}

export interface Body {
  mode: string;
  raw?: string;
  options?: Options;
  urlencoded?: Urlencoded[];
}

export interface Options {
  raw: Raw;
}

export interface Raw {
  language: string;
}

export interface Urlencoded {
  key: string;
  value: string;
  type: string;
}

export interface Response {
  name: string;
  originalRequest: OriginalRequest;
  status: string;
  code: number;
  _postman_previewlanguage: string;
  header: Header3[];
  cookie: any[];
  body: string;
}

export interface OriginalRequest {
  method: string;
  header: Header2[];
  url: Url2;
  body?: Body2;
}

export interface Header2 {
  key: string;
  value: string;
  type: string;
}

export interface Url2 {
  raw: string;
  host: string[];
  query?: Query2[];
  path?: string[];
  protocol?: string;
}

export interface Query2 {
  key: string;
  value: string;
}

export interface Body2 {
  mode: string;
  raw: string;
  options: Options2;
}

export interface Options2 {
  raw: Raw2;
}

export interface Raw2 {
  language: string;
}

export interface Header3 {
  key: string;
  value: string;
}

export interface Event {
  listen: string;
  script: Script;
}

export interface Script {
  type: string;
  exec: string[];
}

export interface Variable {
  key: string;
  value: string;
  type: string;
}
