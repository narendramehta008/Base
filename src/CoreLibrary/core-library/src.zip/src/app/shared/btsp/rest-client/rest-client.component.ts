import { Component } from '@angular/core';
import { Summary } from '@app/core/models/Funcs';
import { Collection, Item, Path } from '../core/Collection';
import testData from './testData.json';

@Component({
  selector: 'btsp-rest-client',
  templateUrl: './rest-client.component.html',
  styleUrl: './rest-client.component.scss',
})
export class RestClientComponent {
  constructor() {
    console.log(this.collection);
    // this.populateSummary();
    this.iterateCollection();
  }
  summaries: Summary[] = [];
  data: any = {};
  currentRequest: Item | undefined;
  collection: Collection = testData;
  position: string = '';

  ngOnInit(): void {}

  iterateCollection() {
    this.iterateCollectionItem(this.collection.item, 0, [
      {
        id: 0,
        name: this.collection.info.name,
      },
    ]);
  }
  iterateCollectionItem(items: Item[], id: number, paths: Path[]) {
    items.forEach((item) => {
      item.id = ++id;
      item.paths = [...paths, { id: id, name: item.name }];

      if (item.item)
        id = this.iterateCollectionItem(item.item, id, [...item.paths!]);
    });
    return id;
  }

  newPosition(event: any) {
    const boundingRect = event.currentTarget.getBoundingClientRect();
    const element = event.currentTarget;

    // const x = event.pageX - boundingRect.left;
    const x = element.offsetLeft;
    const y = element.offsetTop;

    this.position = '(' + x + ', ' + y + ')';
  }

  getVal(event: any) {
    console.log(event);
  }
  click(event: any, execute: boolean = true) {
    execute &&
      document.getElementById(event.currentTarget.dataset.targetId)?.click();
  }
  setRequest(request: any) {
    this.currentRequest = request;
  }
  serialize(data: any) {
    return JSON.stringify(data);
  }
  randomColor() {
    return '#' + (Math.random().toString(16) + '000000').substring(2, 8);
  }
  attrCollapse(item: any) {
    return `#${this.collapseVal(item)}`;
  }
  btnVal(item: any) {
    return this.collapseVal(item, '-btn');
  }
  collapseVal(item: any, suffix: string = '-collapse') {
    return `${item.id ?? 0}${suffix}`;
  }
}
