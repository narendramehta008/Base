import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  CarouselComponent,
  CarouselItemComponent,
} from './carousel/carousel.component';
import { CardComponent } from './card/card.component';
import { RouterModule } from '@angular/router';
import { CardContainerComponent } from './card-container/card-container.component';
import { SharedModule } from '../shared.module';
import { FileSaverModule } from 'ngx-filesaver';
import { CardGroupComponent } from './card-group/card-group.component';
import { SummaryComponent } from './summary/summary.component';
import { ColComponent, TableComponent } from './table/table.component';
import { LoaderComponent } from './loader/loader.component';
import { RestClientComponent } from './rest-client/rest-client.component';
import { AngularDraggableModule } from 'angular2-draggable';
import { CoreModule } from '@app/core/core.module';

@NgModule({
  declarations: [
    CarouselComponent,
    CarouselItemComponent,
    CardComponent,
    CardContainerComponent,
    CardGroupComponent,
    SummaryComponent,
    TableComponent,
    ColComponent,
    LoaderComponent,
    RestClientComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    FileSaverModule,
    AngularDraggableModule,
    CoreModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [
    CarouselComponent,
    CarouselItemComponent,
    CardComponent,
    CardContainerComponent,
    CardGroupComponent,
    SummaryComponent,
    TableComponent,
    ColComponent,
    LoaderComponent,
    RestClientComponent,
  ],
})
export class BtspModule {}
