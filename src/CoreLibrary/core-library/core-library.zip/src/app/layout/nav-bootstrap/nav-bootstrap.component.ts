import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '@app/core/services/authentication.service';
import { ProfileService } from '@app/core/services/profile.service';

@Component({
  selector: 'app-nav-bootstrap',
  templateUrl: './nav-bootstrap.component.html',
  styleUrls: ['./nav-bootstrap.component.scss'],
})
export class NavBootstrapComponent implements OnInit {
  constructor(
    private authService: AuthenticationService,
    public profileService: ProfileService
  ) {}

  ngAfterViewInit() {}

  ngOnInit() {}

  signOut() {
    this.authService.logOut();
  }
  isLoggedIn() {
    return this.authService.isLoggedIn;
  }
}
