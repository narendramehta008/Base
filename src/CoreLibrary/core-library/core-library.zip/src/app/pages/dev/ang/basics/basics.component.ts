import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { Summary } from '@app/core/classes/Funcs';
import { HtmlTemplates } from '@app/core/contents/SampleData';

@Component({
  selector: 'app-basics',
  templateUrl: './basics.component.html',
  styleUrls: ['./basics.component.scss'],
})
export class BasicsComponent implements OnInit {
  summarys: Summary[];
  hTempl = new HtmlTemplates();
  @ViewChild('cliTemplate') cliTemplate: TemplateRef<ElementRef>;
  @ViewChild('firstPartyLibTemplate')
  firstPartyLibTemplate: TemplateRef<ElementRef>;

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.summarys = [
      {
        header: 'Introduction',
        lines: [
          `Angular is application design framework to efficiently develop sophisticated SPA 
          ${this.hTempl.outerLink('https://angular.io/guide/what-is-angular')}`,
          `<ul>
          <li>A component-based framework for building scalable web applications</li>
          <li>A collection of well-integrated libraries that cover a wide variety of features, including routing, forms management, client-server communication, and more</li>
          <li>A suite of developer tools to help you develop, build, test, and update your code</li>
          </ul>`,
        ],
      },
      {
        header: 'Set Up',
        lines: [
          `Familiar with following
        <ul>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript',
          'JavaScript'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/docs/Learn/HTML/Introduction_to_HTML',
          'HTML'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/docs/Learn/CSS/First_steps',
          'CSS'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://www.typescriptlang.org/',
          'Typscript'
        )}</li>
        </ul>
        `,
          `Install Node.js
      `,
          `Install Angular CLI
      <code>npm install -g @angular/cli</code>`,
        ],
      },
      {
        header: 'Components',
        lines: [
          `Components are the building blocks that compose an application. A component includes a TypeScript class with a @Component() decorator, an HTML template, and styles. The @Component() decorator specifies the following Angular-specific information 
          ${this.hTempl.outerLink(
            'https://angular.io/guide/what-is-angular#components'
          )}`,
        ],
      },
      {
        header: 'Templates',
        lines: [
          `Components are the building blocks that compose an application. A component includes a TypeScript class with a @Component() decorator, an HTML template, and styles. The @Component() decorator specifies the following Angular-specific information 
          ${this.hTempl.outerLink(
            'https://angular.io/guide/what-is-angular#templates'
          )}`,
        ],
      },
      {
        header: 'Dependency Injection',
        lines: [
          `It helps us to declare the dependencies of other typescript classes without taking care of instantion, also handles scope of the instance like singleton, transient
          ${this.hTempl.outerLink(
            'https://angular.io/guide/what-is-angular#dependency-injection'
          )}`,
        ],
      },
      {
        header: 'Angular CLI',
        lines: [
          `Recommend way to develop angular applications having cmds
          ${this.hTempl.outerLink(
            'https://angular.io/guide/what-is-angular#angular-cli'
          )}`,
        ],
        templates: [this.cliTemplate],
      },
      {
        header: 'First-party libraries',
        lines: [
          `Libraries we used to develop application
          ${this.hTempl.outerLink(
            'https://angular.io/guide/what-is-angular#first-party-libraries'
          )}`,
        ],
        templates: [this.firstPartyLibTemplate],
      },
      {
        header: 'Lifecycle hooks',
        lines: [
          `A component instance has a lifecycle that starts when Angular instantiates the component class and renders the component view along with its child views`,
          ` ${this.hTempl.outerLink(
            'https://angular.io/guide/lifecycle-hooks#lifecycle-event-sequence'
          )}`,
        ],
      },
      {
        header: 'Component styles',
        lines: [
          `Angular applications are styled with standard CSS. That means you can apply everything you know about CSS stylesheets, selectors, rules, and media queries directly to Angular applications`,
          ` ${this.hTempl.outerLink(
            'https://angular.io/guide/component-styles#component-styles'
          )}`,
        ],
      },
      {
        header: 'Added data in array is not reflecting in UI',
        lines: [
          `Use ChangeDetectorRef and call the detectChanges after data is added.
          <code> this.cdr.detectChanges()</code>`,
          ,
        ],
      },
    ];

    this.cdr.detectChanges();
  }
}
