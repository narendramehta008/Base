import {
  Component,
  ElementRef,
  OnInit,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { Summary } from '@app/core/classes/Funcs';
import { HtmlTemplates } from '@app/core/contents/SampleData';

@Component({
  selector: 'app-basics',
  templateUrl: './basics.component.html',
  styleUrls: ['./basics.component.scss'],
})
export class BasicsComponent implements OnInit {
  summarys: Summary[];
  hTempl = new HtmlTemplates();
  @ViewChild('cliTemplate') cliTemplate: TemplateRef<ElementRef>;
  @ViewChild('firstPartyLibTemplate')
  firstPartyLibTemplate: TemplateRef<ElementRef>;

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.summarys = [
      {
        header: 'Introduction',
        lines: [
          `Angular is application design framework to efficiently develop sophisticated SPA 
          ${this.hTempl.outerLink('https://angular.io/guide/what-is-angular')}`,
          `<ul>
          <li>A component-based framework for building scalable web applications</li>
          <li>A collection of well-integrated libraries that cover a wide variety of features, including routing, forms management, client-server communication, and more</li>
          <li>A suite of developer tools to help you develop, build, test, and update your code</li>
          </ul>`,
        ],
      },
      {
        header: 'Set Up',
        lines: [
          `Familiar with following
        <ul>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript',
          'JavaScript'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/docs/Learn/HTML/Introduction_to_HTML',
          'HTML'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://developer.mozilla.org/docs/Learn/CSS/First_steps',
          'CSS'
        )}</li>
        <li> ${this.hTempl.outerLink(
          'https://www.typescriptlang.org/',
          'Typscript'
        )}</li>
        </ul>
        `,
          `Install Node.js
      `,
          `Install Angular CLI
      <code>npm install -g @angular/cli</code>`,
        ],
      },
      {
        header: 'hide if have one child',
        lines: [``],
        codes: [
          `
          .slick-dots {
              li {
                display: inline-block;
              }
              li:only-child {
                display: none;
              }
            }`,
        ],
      },
    ];
  }
}
