import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '@app/core/services/auth-guard.service';
import { DevComponent } from './dev.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: DevComponent,
      },
      {
        path: 'ang',
        loadChildren: () =>
          import('./ang/ang-routing.module').then((m) => m.AngRoutingModule),
        canActivate: [AuthGuardService],
      },
      {
        path: 'dot-net',
        loadChildren: () =>
          import('./dot-net/dot-net-routing.module').then(
            (m) => m.DotNetRoutingModule
          ),
        canActivate: [AuthGuardService],
      },
      {
        path: 'html',
        loadChildren: () =>
          import('./html/html-routing.module').then((m) => m.HtmlRoutingModule),
        canActivate: [AuthGuardService],
      },
      {
        path: 'css',
        loadChildren: () =>
          import('./css/css-routing.module').then((m) => m.CssRoutingModule),
        canActivate: [AuthGuardService],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DevRoutingModule {}
