import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnChanges,
  OnInit,
  SimpleChanges,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { Summary } from '@app/core/classes/Funcs';

@Component({
  selector: 'app-basics',
  templateUrl: './basics.component.html',
  styleUrls: ['./basics.component.scss'],
})
export class BasicsComponent implements OnInit, OnChanges {
  summarys: Summary[];
  @ViewChild('changeColorTemplate')
  changeColorTemplate: TemplateRef<ElementRef>;
  @ViewChild('sampleTemplate') sampleTemplate: TemplateRef<ElementRef>;
  @ViewChild('roundTemplate') roundTemplate: TemplateRef<ElementRef>;
  @ViewChild('buttonTemplate') buttonTemplate: TemplateRef<ElementRef>;
  @ViewChild('pushSwitchTemplate') pushSwitchTemplate: TemplateRef<ElementRef>;
  @ViewChild('toggleSwitchTemplate')
  toggleSwitchTemplate: TemplateRef<ElementRef>;
  @ViewChild('radioTemplate') radioTemplate: TemplateRef<ElementRef>;
  @ViewChild('sampleTextTemplate') sampleTextTemplate: TemplateRef<ElementRef>;
  @ViewChild('formTemplate') formTemplate: TemplateRef<ElementRef>;
  @ViewChild('loadingTemplate') loadingTemplate: TemplateRef<ElementRef>;
  @ViewChild('musicPlayerTemplate')
  musicPlayerTemplate: TemplateRef<ElementRef>;
  @ViewChild('neuElementsTemplate')
  neuElementsTemplate: TemplateRef<ElementRef>;
  @ViewChild('selectTemplate')
  selectTemplate: TemplateRef<ElementRef>;

  select: Select;

  //https://codepen.io/jackdomleo7/pen/mdeowoz
  // https://codepen.io/myacode/pen/PoqQQNM
  constructor(private cdr: ChangeDetectorRef) {}
  ngOnChanges(changes: SimpleChanges): void {}

  ngOnInit(): void {}
  ngAfterViewInit() {
    // this.select = new Select();

    this.summarys = [
      {
        header: 'Introduction',
        lines: [
          `Neumorphic card however pretends to extrude from the background. It’s a raised shape made from the exact same material as the background. When we look at it from the side we see that it doesn’t “float”.
          This effect is pretty easy to achieve by playing with two shadows, one at negative values while the other at positive.
           But for it to work our background cannot be fully black or fully white.
            It needs at least a tiny bit of tint so both dark and “light” shadows will be visible. You can use any hue for the background so it can be warmer or colder depending on your choice. But white and dark shadows have to be visible on it, if slightly.
            <a href="https://uxdesign.cc/neumorphism-in-user-interfaces-b47cef3bf3a6#:~:text=Neumorphic%20card%20however%20pretends%20to%20extrude%20from%20the%20background">Refer Link </a>
            `,
        ],
        templates: [
          this.changeColorTemplate,
          this.sampleTemplate,
          this.roundTemplate,
        ],
      },
      {
        header: 'Card',
        lines: [` Normal Card `],
        codes: [
          `box-shadow: 12px 12px 16px 0 rgba(0, 0, 0, 0.25),
          -8px -8px 12px 0 rgba(255, 255, 255, 0.3);`,
        ],
      },
      {
        header: 'Pressed Card',
        codes: [
          `box-shadow: -10px -10px 15px rgba(255, 255, 255, 0.5),
        10px 10px 15px rgba(70, 70, 70, 0.12),
        inset -10px -10px 15px rgba(255, 255, 255, 0.5),
        inset 10px 10px 15px rgba(70, 70, 70, 0.12);`,
        ],
      },
      {
        header: 'Button Template',
        templates: [this.sampleTemplate],
      },
      {
        header: 'Push Switch Template',
        templates: [this.pushSwitchTemplate],
      },
      {
        header: 'Toggle Switch Template',
        templates: [this.toggleSwitchTemplate],
      },
      {
        header: 'Radio Template',
        templates: [this.radioTemplate],
      },
      {
        header: 'Sample Text',
        templates: [this.sampleTextTemplate],
      },
      {
        header: 'Form',
        templates: [this.formTemplate],
      },
      {
        header: 'Loading',
        templates: [this.loadingTemplate],
      },
      {
        header: 'Positioning',
        lines: [
          'Give height and set parent position to relative if child position is absolute, like this loading.',
        ],
      },
      {
        header: 'Music Player',
        templates: [this.musicPlayerTemplate],
      },
      {
        header: 'Neu Elements',
        templates: [this.neuElementsTemplate],
      },
    ];

    this.cdr.detectChanges();
  }

  changeColor(e: any) {
    document.documentElement.style.cssText = `
    --baseColor: ${e.target.value}
    `;
  }
}

class Select {
  select: any;
  // i:any;
  j: any;
  size: any;
  selElmntSize: any;
  selElmnt: any;

  constructor() {
    let a: any, b: any, c: any;
    /*look for any elements with the class "custom-select":*/
    this.select = document.getElementsByClassName('custom-select');
    this.size = this.select.length;
    for (let i = 0; i < this.size; i++) {
      this.selElmnt = this.select[i].getElementsByTagName('select')[0];
      this.selElmntSize = this.selElmnt.length;
      /*for each element, create a new DIV that will act as the selected item:*/
      a = document.createElement('DIV');
      a.setAttribute('class', 'select-selected');
      a.innerHTML =
        this.selElmnt.options[this.selElmnt.selectedIndex].innerHTML;
      this.select[i].appendChild(a);
      /*for each element, create a new DIV that will contain the option list:*/
      b = document.createElement('DIV');
      b.setAttribute('class', 'select-items select-hide');
      for (let j = 1; j < this.selElmntSize; j++) {
        /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
        c = document.createElement('DIV');
        c.innerHTML = this.selElmntSize.options[j].innerHTML;
        c.addEventListener('click', function (e) {
          /*when an item is clicked, update the original select box,
        and the selected item:*/
          var y, i, k, s, h, sl, yl;
          s = this.parentNode.parentNode.getElementsByTagName('select')[0];
          sl = s.length;
          h = this.parentNode.previousSibling;
          for (i = 0; i < sl; i++) {
            if (s.options[i].innerHTML == this.innerHTML) {
              s.selectedIndex = i;
              h.innerHTML = this.innerHTML;
              y = this.parentNode.getElementsByClassName('same-as-selected');
              yl = y.length;
              for (k = 0; k < yl; k++) {
                y[k].removeAttribute('class');
              }
              this.setAttribute('class', 'same-as-selected');
              break;
            }
          }
          h.click();
        });
        b.appendChild(c);
      }
      this.select[i].appendChild(b);
      a.addEventListener('click', function (e) {
        /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
        e.stopPropagation();
        this.closeAllSelect(this);
        this.nextSibling.classList.toggle('select-hide');
        this.classList.toggle('select-arrow-active');
      });
    }

    /*if the user clicks anywhere outside the select box,
then close all select boxes:*/
    document.addEventListener('click', (elmnt) => {
      this.closeAllSelect(elmnt);
    });
  }
  closeAllSelect(elmnt) {
    /*a function that will close all select boxes in the document,
    except the current select box:*/
    let x,
      y,
      i,
      xl,
      yl,
      arrNo = [];
    x = document.getElementsByClassName('select-items');
    y = document.getElementsByClassName('select-selected');
    xl = x.length;
    yl = y.length;
    for (i = 0; i < yl; i++) {
      if (elmnt == y[i]) {
        arrNo.push(i);
      } else {
        y[i].classList.remove('select-arrow-active');
      }
    }
    for (i = 0; i < xl; i++) {
      if (arrNo.indexOf(i)) {
        x[i].classList.add('select-hide');
      }
    }
  }
}
