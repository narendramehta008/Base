import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-neu',
  templateUrl: './neu.component.html',
  styleUrls: ['./neu.component.scss'],
})
export class NeuComponent implements OnInit {
  dataSource: CardComponent[] = [];

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    let card = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Introduction',
        fontClass: 'fg-theme',
        media: {
          src: '/assets/images/info-blue.png',
        },
        onHoverShowDetails: true,
        redirectUrl: '/designs/neu/basics',
        redirectName: 'Visit',
        text: 'Basic introduction about the Neumorphism and sample elements.',
      }),
      // new CardComponent(this.utilService).setCardValue({
      //   title: 'Twitter',
      //   fontClass: 'fg-theme',
      //   media: {
      //     src: '/assets/images/twt-logo.png',
      //   },
      //   onHoverShowDetails: true,
      //   redirectUrl: '/services/twt',
      //   redirectName: 'Visit',
      //   text: "Join the conversation! Expand your social network and stay updated on what's trending now. Retweet, chime in on a thread, go viral, or just scroll through .",
      // }),

      // new CardComponent(this.utilService).setCardValue({
      //   title: 'Pinterest',
      //   fontClass: 'fg-theme',
      //   media: {
      //     src: '/assets/images/pin-logo.png',
      //   },
      //   onHoverShowDetails: true,
      //   redirectUrl: '/services/pin',
      //   redirectName: 'Visit',
      //   text: "Looking for creative ideas? Whether you're planning your next big travel adventure, searching for home design concepts, looking for fashion & fitness ...",
      // }),
      // new CardComponent(this.utilService).setCardValue({
      //   title: 'Data Structure and Algorithms',
      //   fontClass: 'fg-theme',
      //   media: {
      //     src: '/assets/images/DSA.jpg',
      //   },
      //   onHoverShowDetails: true,
      //   redirectUrl: '/dsa/introduction',
      //   redirectName: 'Visit',
      //   text: 'Here we discuss basic cpncepts of DS',
      // }),
    ];
    this.dataSource.push(...card);
  }
}
