import { Component, OnInit } from '@angular/core';
import { UtilsService } from '@app/core/services/utils.service';
import { CardComponent } from '@app/shared/components/card/card.component';

@Component({
  selector: 'app-designs',
  templateUrl: './designs.component.html',
  styleUrls: ['./designs.component.scss'],
})
export class DesignsComponent implements OnInit {
  dataSource: CardComponent[] = [];

  constructor(private utilService: UtilsService) {}

  //https://similarpng.com/
  ngOnInit(): void {
    let card = [
      new CardComponent(this.utilService).setCardValue({
        title: 'Glassmorphism',
        fontClass: 'fg-theme',
        media: {
          src: '/assets/images/glass.png',
        },
        onHoverShowDetails: true,
        redirectUrl: '/designs/glass',
        redirectName: 'Visit',
        text: 'Glassy looking designs for web and mobile apps.',
      }),
      new CardComponent(this.utilService).setCardValue({
        title: 'Neumorphism',
        fontClass: 'fg-theme',
        cardClass: 'card-neu',
        media: {
          src: '/assets/images/neu.png',
        },
        onHoverShowDetails: true,
        redirectUrl: '/designs/neu',
        redirectName: 'Visit',
        text: 'Design trend where surface floating on top of our perceived background and casting a shadow onto it.',
      }),
    ];
    this.dataSource.push(...card);
  }
}
