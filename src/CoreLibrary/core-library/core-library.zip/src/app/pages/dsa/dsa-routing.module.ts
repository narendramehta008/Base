import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DsaComponent } from './dsa.component';
import { IntroductionComponent } from './introduction/introduction.component';

const routes: Routes = [
  {
    path: '',
    component: DsaComponent,
    children: [
      {
        path: 'introduction',
        component: IntroductionComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DsRoutingModule { }
