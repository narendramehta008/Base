import {
  AfterContentInit,
  Component,
  ContentChild,
  Input,
  OnInit,
  TemplateRef,
} from '@angular/core';
import { CardTemplate } from '@app/core/models/CardTemplates';
import { FileQueryModel } from '@app/core/models/QueryModels';
import { UtilsService } from '@app/core/services/utils.service';
import { environment } from 'src/environments/environment';
import { String } from 'typescript-string-operations';

export interface IMedia {
  src?: string;
  type?: 'Audio' | 'Video' | 'Image';
  ext?: string;
}

export interface ICardTemplate {
  media?: IMedia;
  title?: string;
  text?: string;
  redirectUrl?: string;
  redirectName?: string;
  showDownload?: boolean;
  onHoverShowDetails?: boolean;
  fontClass?: string;
  cardClass?: string;
}

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss'],
})
export class CardComponent implements OnInit {
  @Input() cards: ICardTemplate[] = [];
  @Input() cardTemplate: CardComponent;

  customCardTemplate: TemplateRef<any>;
  currentIndex = 0;

  slickConfig = {
    enabled: false,
    initialSlide: this.currentIndex,
    arrows: true,
    swipe: true,
    dots: true,
    // slidesToShow: 4,
    // slidesToScroll: 4,
    // autoplay: true,
    // autoplaySpeed: 2000,
    method: {},
    event: {
      init: (event, slick) => {
        slick.slickGoTo(this.currentIndex);
      },
      afterChange: (event, slick, currentSlide, nextSlide) => {
        this.currentIndex = currentSlide;
      },
    },
  };

  constructor(private utilService: UtilsService) {}

  ngOnInit(): void {
    if (this.cardTemplate) {
      // this.cardTemplate.cards = this.cardTemplate.cards;
      this.customCardTemplate = this.cardTemplate.customCardTemplate;
    }
  }

  setCardValue(card?: ICardTemplate) {
    this.cards.push(this.setCardDefault(card));
    return this;
  }
  setCards(cards?: ICardTemplate[]) {
    cards.map((card) => {
      this.cards.push(this.setCardDefault(card));
    });
    return this;
  }

  setCardDefault(card?: ICardTemplate) {
    card.title = card.title || 'title';
    card.text =
      card.text ||
      "Some quick example text to build on the card title and make up the bulk of the card's content.";
    card.redirectName = card.redirectName || 'Link';
    card.showDownload = false;
    card.media &&
      (card.media = { src: card.media.src, type: card.media.type || 'Image' });
    return card;
  }

  downloadMedia(mediaSrc) {
    // window.open(this.imageSrc);
    this.utilService
      .downloadWithResponseFileName(
        environment.apiEndPoint.file.downloadFile,
        null,
        new FileQueryModel(mediaSrc)
      )
      .subscribe((res) => {});
    // this.utilService.downloadWithResponseFileName(this.imageSrc);
  }
}
